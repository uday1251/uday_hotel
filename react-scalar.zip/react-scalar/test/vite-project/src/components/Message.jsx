import React from 'react'

function Message() {
const sayHello = () => {
        console.log("hello");
        alert("Hello");
}
  return (
        <button onClick={sayHello}>Click me to say Hello</button>   
  )
}

export default Message
