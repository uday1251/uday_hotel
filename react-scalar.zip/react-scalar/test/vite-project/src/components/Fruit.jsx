import React from 'react'

function Fruit({name, price}) {
    console.log(price);
  return (
    <li>{price >150 ? <h3>The price of {name} is {price}</h3> : " "}</li>
  )
}

export default Fruit
