import React from 'react'

function Todolist() {
  return (
    <div className='todo'>
    <p>go to the gym</p>
    <div className='actions'>
        <input type='checkbox' />
        <button>Delete</button>
    </div>
</div>
  )
}

export default Todolist
