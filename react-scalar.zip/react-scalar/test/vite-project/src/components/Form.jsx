import React, { useState } from 'react'

function Form() {
    const  [name,setName] = useState({firstname :"", lastname:""});
     const HandelSubmit = (e) => {
        e.preventDefault();
            console.log(name.firstname + ' ' + name.lastname);
     }
  return (
    <div>
        <h2>Forms</h2>
        <form>
            <h3>{name.firstname} {name.lastname}</h3>
            <label>First Name :</label>
            <input type='text' value ={name.firstname} onChange={(e)=> setName({...name,firstname:e.target.value})} />
            <label>Last Name:</label>
            <input type='text' value ={name.lastname} onChange={(e)=> setName({...name,lastname:e.target.value})} />
            <button onClick={HandelSubmit}>Submit</button>
        </form>
         
    </div>
  )
}

export default Form
