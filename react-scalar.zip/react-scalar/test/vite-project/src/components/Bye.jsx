import React from 'react'

export default function Bye() {
  return (
    <div>
        <h2>Bye from Bye componenet.</h2>
    </div>
  )
}
