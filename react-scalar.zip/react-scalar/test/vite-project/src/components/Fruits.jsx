import React from 'react'
import Fruit from './Fruit';

function Fruits() {
    let fruites = [
                   {name : 'Apple',price:150},
                   {name : 'Orange',price:180},
                   {name : 'Mango',  price:100},
                   {name : 'Pinaaple',price:200},

                 ];
  return (
    <div>
        <ul>
        {fruites.map(fruite=>(
          < Fruit  name={fruite.name} price={fruite.price}/> 
        ))}
      </ul>
    </div>
  )
}

export default Fruits
