import React, {useState} from 'react'

function Counter() {
   const [count,setCount] = useState(0);

   const  [factor,setFactor] = useState(1);
   const inCrementCount  = ()=> {

        return setCount(count+factor);
         
    };

    const decrementCount = () => {
        return setCount(count-factor);
    }

    const incrementFactor = () => {
        return setFactor(factor+1);
    }
    const decrementFactor = () => {
        return setFactor(factor-1);
    }
  return (
    <div>
        <h1>This is My counter: {count}</h1>
        <button  onClick={inCrementCount}>Increment</button>
        <button onClick={decrementCount}>Decrement</button>

        <h1>set my factor {factor}</h1>
        <button  onClick={incrementFactor}>Increment</button>
        <button onClick={decrementFactor}>Decrement</button>
    </div>
  )
}

export default Counter
