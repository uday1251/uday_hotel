function Hello(props){
    console.log(name);
    
   
    return (
         <h1>Hello from Hello component. {props.name} {props.study}</h1>
    )
}

export default Hello;