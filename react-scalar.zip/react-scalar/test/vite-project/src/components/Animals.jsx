import React from 'react'

function Animals() {
    let animals = ['Cat','Dog','Hourse'];
  return (
    <div>
        <ul>
            {animals.map((animal)=>(
                <li key ={animal}>{animal}</li>
            ))}
        </ul>
    </div>
  );
}

export default Animals;