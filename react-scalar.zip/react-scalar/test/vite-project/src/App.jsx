import Hello from "./components/Hello";
import Bye from "./components/Bye";
import Animals from "./components/Animals";
import Fruits from "./components/Fruits";
import Message from "./components/Message";
import Counter from "./components/Counter";
import Form from "./components/Form";
function App() {
  const name = "My Name is Uday Bikumandla.";
  const study = "M.tech";
return (
     <>
        <Form />
     </>
  )
}

export default App
