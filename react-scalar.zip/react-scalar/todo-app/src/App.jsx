import { useState } from 'react'
import "./App.css";
import AddContaner from './components/AddContaner';
import TodoContainer from './components/TodoContainer';
function App() {
 
  const [inputVal , setInputVal] = useState('');

  const [todos, setTodos] =  useState([]);

   function WriteTodo(e)
   {

      setInputVal(e.target.value);
   }

   function addTodo()
   {
    console.log("hello");
    if(inputVal!='')
    {
      setTodos((prevTodos)=>[...prevTodos, inputVal]);
      setInputVal('');
     
    }

   }
   console.log(todos);

   function deleteTodo(todoIndex)
   {
      
 
      setTodos((prevTodos)=>prevTodos.filter((prevTodos,prevTodosIndex)=>{
      
          return prevTodosIndex!=todoIndex;

      }));
   }
  return (
    <>
     <main>
        <h1>Todo List</h1>
        <AddContaner  inputVal={inputVal} WriteTodo={WriteTodo} addTodo={addTodo}/>
        <TodoContainer todos={todos} deltodo={deleteTodo} />
     </main>
     
    </>
  )
}

export default App
