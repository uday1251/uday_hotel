import logo from "./assets/images/logo.png";
import "./assets/css/header.css";
import rest from "./assets/images/foodcard1.jpg";

let HeaderStyle = {
    backgroundColor:"red"
}
const Header = () => {
 return (
    <div className="header" style={HeaderStyle}>
        <img src={logo} alt="Logo" className="logo" />
        <ul className="nav-list">
        <li className="nav-item">Home</li>
        <li className="nav-item">Contact</li>
        <li className="nav-item">Help</li>
        <li className="nav-item">Cart</li>
        </ul>
        </div>
 )
}

const Body = () => {
        return (
            <div>
                <div><Search /></div>
                <div className="card-contianer">
                   <FoodCard name ="Biryani, North Indian, Chinese" location="koti"/>
                   <FoodCard name ="Biryani" location="Vanasthalipuram"/>
                   <FoodCard name ="Chinese, Biryani" location="Adhithi Biryani House"/>
                
                </div>
            </div>
        )
}

const Search = () => {
    return (
        <div>Search</div>
    )
}

const FoodCard = (props) => {
    let {name, location} = props;
    return (
        <div className="food-card">
          <img src={rest} alt="Restaurant" className="food-image" />
          <div className="food-details">
            <p className="food-name">{name}</p>
            <p className="food-cuisine">Biryani, Kebabs, Hyderabadi</p>
            <p className="food-location">{location}</p>
          </div>
        </div>
      );
       
}


const HomePage = () => {
    return <div>
           <Header />
           <Body />
        </div>
}

export  default HomePage;