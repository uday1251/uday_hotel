// import React from "react";
// import ReactDOM from "react-dom/client";
//     console.log(React);///
//     // var heading = React.createElement("h1",{},"Hello World");
    
//     const root =ReactDOM.createRoot(document.getElementById("root"));

//     var jaxheading = <h1 id ="header">Hello</h1>
//     //console.log(root);
//     root.render(jaxheading);




//var x =10;



console.log(parseInt("10+2"));
console.log(parseInt("7FM"));
console.log(parseInt("M7F"));

return false;

import React from "react";
import ReactDOM from "react-dom/client";
import HomePage from "./HomePage";

 //const heading = ReactDOM.createElement("h1",{},"Hello React");

 const root = ReactDOM.createRoot(document.getElementById("root"));
 var jaxheading = <h1 id="header">Hello</h1>



 root.render(<HomePage />);