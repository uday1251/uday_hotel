<?php

abstract class Vehicle{
    abstract public function move();
}   

class Bike extends Vehicle
{
    public function move(){
        echo "Bike is moveing";
    }
}

$bike  = new Bike();

$bike->move();