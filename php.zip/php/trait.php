<?php
trait Hello {
     public function sayHello()
     {
        echo "Hello Uday";
     }
}

class Greting{
    use Hello;
}


$obj = new Greting();

$obj->sayHello();