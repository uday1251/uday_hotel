<?php

function haveSameCharacters($str1,$str2)
{
    $str1 = strtolower(str_replace(' ','',$str1));

    $str2 = strtolower(str_replace(' ', '',$str2));

    if(strlen($str1)!= strlen($str2))
    {
        return "false";
    }

    $arr1 = str_split($str1);

    $arr2 = str_split($str2);


    sort($arr1);
    sort($arr2);
   

    if($arr1==$arr2)
    {
        return "true";
    }
    else{
        return "false";
    }
}


echo haveSameCharacters("listen", "silent");

