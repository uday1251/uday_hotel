<?php

class Car
{
    public $color;
    public $brand;

    public $name;


    public function __construct($name)
    {
            $this->name = $name;

            echo "User name $this->name created. <br>";
    }

    public  function drive()
    {
        echo "This $this->brand car is driving";
    }

    public function color()
    {
        echo "I Love $this->color code <br>";
    }


    public function __destruct()
    {
        echo "User $this->name destoryed. ";
    }
}

$car1 = new Car("Uday");

$car1->brand = "BMW";

$car1->color = "Green";


$car1->drive();
echo "<br>";
$car1->color();
?>