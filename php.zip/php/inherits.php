<?php

class Animal{
     
    public function sound()
    {
        echo "Animal Make a Sound.";
    }

    public function Color()
    {
        echo "<br> color is perfect";
    }
}


class Dog extends Animal{
     public function sound()
     {
        echo "Dog Barks.";
     }
}


$dog = new Dog();
$dog->sound();

$dog->Color();