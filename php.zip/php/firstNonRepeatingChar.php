<?php

function firstNonRepeatingChar($str){
        $charCount = [];

        $length = strlen($str);

        for($i=0; $i<$length; $i++){
            $char = $str[$i];
           if(isset($charCount[$char])){
             $charCount[$char]++;
           }
           else{
            $charCount[$char] =1;
           }
        }


        for ($i=0; $i<$length; $i++)
        {
            
            if($charCount[$str[$i]]==1)
            {
                
                return $str[$i];
            }
        }
        return null;
}


echo firstNonRepeatingChar("swiss");
//echo firstNonRepeatingChar("aabbccddeefg");
//echo firstNonRepeatingChar("abcabcabcd");// Output: "d"