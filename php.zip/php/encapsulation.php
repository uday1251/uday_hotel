<?php
class  BankAccount
{

    private $balance = 0;

    public function deposit($ammount)
    {
        $this->balance += $ammount;
    }


    public function getBalance()
    {
        return $this->balance;
    }

}

$account = new BankAccount();

$account->deposit("10000");

echo $account->getBalance();

?>