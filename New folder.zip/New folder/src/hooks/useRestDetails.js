import { useEffect, useState } from "react";
import {REST_DETAILS_URL } from "../utils/constants";
const useResDetails = (resID) =>{
    const [resData, setResData] = useState([]);
    const [resBasicData, setResBasicData] = useState([]);
    useEffect(() => {
       const  fetchData = async () => {
            let data = await fetch(`${REST_DETAILS_URL}${resID}`)
            let resDatails = await data.json();  
           
            //console.log(resDatails);
            setResBasicData(resDatails?.data?.cards[0]?.card?.card?.info);
            //setResData(resDatails?.data?.cards[1].groupedCard?.cardGroupMap?.REGULAR?.cards[1]?.card?.card?resDatails?.data?.cards[1]?.groupedCard?.cardGroupMap?.REGULAR?.cards[1]?.card?.card:resDatails?.data?.cards[2]?.groupedCard?.cardGroupMap?.REGULAR?.cards[1]?.card?.card);
            setResData(resDatails?.data?.cards[1].groupedCard?.cardGroupMap?.REGULAR?.cards?resDatails?.data?.cards[1]?.groupedCard?.cardGroupMap?.REGULAR?.cards:resDatails?.data?.cards[2]?.groupedCard?.cardGroupMap?.REGULAR?.cards);
        }
        fetchData(); 
    },[resID])
     return [resData, setResData, resBasicData, setResBasicData ];
   

}

export default useResDetails;