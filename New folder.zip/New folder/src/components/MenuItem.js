const MenuItem = (props)=>{
    const {item} = props;
    //const [showList, setShowList] = useState(false);
    const {showList} = props;
    const {index} = props;
    console.log("index:"+index);
    let rupee = new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 0,
    });
    showItems = () =>{
        console.log("Called!.");
      
        //showList?setShowList(false):setShowList(true);
        props.setShowList(index);
    }
    return (
        <div className="mb-4">
             <h2>{item.itemtitle}</h2>
            <div className="flex w-full m-auto justify-between bg-yellow-600 p-4" onClick={showItems}>
                <h2 className="font-bold text-md text-white">{item.title}</h2>
                {
                    item.itemCards?<span aria-hidden="true" className="before:content-['\E923'] text-white"></span>:''
                }
                
            </div>
            {
                showList && <div className="w-full m-auto bg-gray-100 p-4">
                 {
                    item.itemCards.map((itemcard,index)=>{
                        console.log(itemcard);
                        let price = (itemcard.card.info.defaultPrice)?itemcard.card.info.defaultPrice:itemcard.card.info.price;
                        return(
                            <div className="grid grid-cols-4 gap-4 border-b border-gray-300" key={index}>
                        <div className="col-span-3 p-4">
                            <div>
                                <p className="font-bold">{itemcard.card.info.name}</p>
                                <p>{rupee.format(price/100)}</p>
                                
                            </div>

                        </div>
                        <div className="col-span-1 p-4">
                            {itemcard.card.info.imageId ?
                            (<img src= {'https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_208,h_208,c_fit/'+itemcard.card.info.imageId} />): ('')
                            }
                        
                        </div>
                    </div>
                        )
                    })
                 }   
            </div>
            }      
            
        </div>
    )
}

export default MenuItem;