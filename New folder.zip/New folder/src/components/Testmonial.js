import React from "react";

class Testmonial extends React.Component{

    render(){
            <div>
                <h2>Users List</h2>
            </div>
    }
}

export default Testmonial;