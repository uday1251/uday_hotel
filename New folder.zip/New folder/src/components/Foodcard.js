import React from "react";
import restarent_image1 from "../../images/restarent_image1.jpg";
import { IMG_URL } from "../utils/constants";
import Details from "./Details";
const Foodcard = (props) => {
    //console.log(props.resData.info.cuisines.toString().slice(0, 26));
    return (
        <div className="py-2.5">
               <img src={IMG_URL+props.resData.info.cloudinaryImageId} className="w-48 h-40 rounded-3xl object-cover" />
                <p>{props.resData.info.name}</p>
                <p>{props.resData.info.avgRating} Star</p>
                <p>{props.resData.info.cuisines.join(', ').slice(0, 25)+'...'}</p>
                <p>{props.resData.info.areaName}</p> 
        </div>  
      )
}

export const FoodcardWithOffer = (FC) => {
      return (props) =>{
           return(
              <div className="relative">
                <h1 className="px-3 absolute text-base font-black text-white inset-y-1/2 left-1.5 tracking-tighter antialiased">{props.resData.info.aggregatedDiscountInfoV3.header} {props.resData.info.aggregatedDiscountInfoV3.subHeader}</h1>
                <FC resData={props.resData} />
                
              </div>

           ) 
      } 
}
export default Foodcard