import { useParams } from "react-router-dom";
import Shimmer from "./Shimmer";
import { MENU_ITEM_IMG } from "../utils/constants";
import useResDetails from "../hooks/useRestDetails";
import Menu from "./Menu";

const Details = ()=>{
    const {resID} = useParams();
    const [resData, setResData, resBasicData, setResBasicData ] = useResDetails(resID);
     console.log(resData);
   const categoryList  = resData.filter((item)=>{
            if(item.card.card['@type']=="type.googleapis.com/swiggy.presentation.food.v2.ItemCategory" || item.card.card['@type']=='type.googleapis.com/swiggy.presentation.food.v2.NestedItemCategory')
            {  
                return  item.card.card['@type'];
            }
   });
   //console.log(categoryList);
   if(resData.length==0)
    {
        return (<Shimmer/>);
    }
    let rupee = new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 0,
    });
    return(
    <div className="container lg:max-w-screen-lg mx-auto px-5 mt-10">
          {<div className="grid grid-cols-4 gap-4">
            <div className="col-span-3 p-4">
                <div>
                    <p className="text-xl font-bold">{resBasicData.name}</p>
                    <span className="font-semibold text-xs text-gray-400">{resBasicData.cuisines.join(",")}</span>
                    <br></br>
                    <span className="font-semibold text-xs text-gray-400">{resBasicData.areaName}</span>
                </div>           
            </div>
            <div className="col-span-1 p-4"><button className="w-18 h-16 p-2   border bg-transparent border-gray-300 rounded-md"><span className="border-b p-2.5 border-gray-200"><span className="text-green-600 text-lg pr-1.5">*</span><span className="text-green-600 text-lg">{resBasicData.avgRatingString}</span></span><br></br><span className="text-xs">{resBasicData.totalRatingsString}</span></button></div>
        
         </div>}
        {
            categoryList.map((menucategory, index)=>{
             console.log(menucategory);
               return (
                    <Menu  key={index} categoryItems={menucategory}/>
                  )
            })
        }
         
       {/* <MenuItem /> */}
       
         
    </div>
    );

}

export default Details;