import Foodcard, {FoodcardWithOffer} from "./Foodcard";
import Slider from "./Slider";
import { useEffect, useState } from "react";
import Shimmer from "./Shimmer";
import { Link } from "react-router-dom";

const Body = () => {
    
let [res, setRestaurants] = useState([]);
let [resCopy, setRestaurantsCopy] = useState();
let [searchTerm,setSearchTerm] = useState("");
let [slider, setSliders] = useState([]);

const FoodCardOfferComponent =  FoodcardWithOffer(Foodcard);
useEffect(()=>{
    const getRestaurantData = async () =>{
        let data = await fetch("https://www.swiggy.com/dapi/restaurants/list/v5?lat=17.3413189&lng=78.5315546")
        let resData = await data.json();
        setRestaurants(resData?.data?.cards[5]?.card?.card?.gridElements?.infoWithStyle?.restaurants);
        setRestaurantsCopy(resData?.data?.cards[5]?.card?.card?.gridElements?.infoWithStyle?.restaurants)
        setSliders(resData?.data?.cards[0]?.card?.card?.imageGridCards?.info);
        
        
    } 
    // let data = fetch("https://www.swiggy.com/dapi/restaurants/list/v5?lat=17.385044&lng=78.486671")
    // .then((data)=>{
    //     return data.json();
    // }).then((resData)=>{
    //     console.log("component rendered");
    //     console.log(resData);
    // }).catch((err)=>{
    //     console.log(err);
    // })
    //console.log("uday");
   getRestaurantData();
   
   
}, [] );
console.log(resCopy);




if(res.length==0)
{
    return (<Shimmer/>);
}
    return (
        <div>
           
            <div className="container lg:max-w-screen-lg mx-auto px-5">
               
                    <Slider slider={slider}/>
                 
                <h2 className="text-2xl font-semibold">Restaurants with online food delivery in Hyderabad</h2>
                <div className="flex">
                <div className="flex">
                    <input  value={searchTerm} onChange={(e)=>{
                         setSearchTerm(e.target.value);
                    }}type="text" className="bg-red-50 border border-red-500 text-red-900 placeholder-red-700 text-sm rounded-lg focus:ring-red-500 block w-full p-2.5 dark:text-red-500 dark:placeholder-red-500 dark:border-ring-pink-800"></input>
                    <button onClick= {()=>{
                        if(searchTerm.length>0){
                            const searchData = resCopy.filter((resd)=>{
                                return resd.info.name.toLowerCase().includes(searchTerm.toLowerCase());     
                              })
                             setRestaurantsCopy(searchData);
                        }
                        else{
                            setRestaurantsCopy(res);
                        }
                            
                    }} className="text-white bg-gradient-to-r from-pink-400 via-pink-500 to-pink-600 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-pink-300 dark:focus:ring-pink-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Search</button>
                </div>
                <button className="w-fullw-9/12 h-10 bg-purple-400 px-4 text-white" onClick={()=>{
                        setRestaurantsCopy(res);
                        filtered = resCopy.filter((resdata)=>{
                            return resdata.info.avgRating > 4.3;
                        }) ;
                        console.log(filtered);
                        setRestaurantsCopy(filtered);
                        
                    }}>Get Top getRestarentData
                    </button>
                </div>
                <div className="grid grid-cols-4">
                    {
                        resCopy.map((resData, index) => {
                            return <Link to={`restaurants/${resData.info.id}`} key={index}>
                                {
                                     resData?.info?.aggregatedDiscountInfoV3?.header ? 
                                    <FoodCardOfferComponent  resData= {resData}/> : 
                                    <Foodcard  key={resData.info.id}  resData= {resData} />
                                }
                            
                            </Link>
                        })
                    }
                </div>
            </div>
        </div>
     )
};

export default Body;