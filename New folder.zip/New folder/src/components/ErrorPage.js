import { useRouteError } from "react-router-dom";
const ErrorPage = () =>{
    let {status,statusText} = useRouteError();
    console.log(useRouteError());
    return(
         <div>
            <h1 className="text-9xl font-bold text-purple-400">{status} </h1>
            <h1 className="text-6xl font-medium py-8">{statusText}</h1>
         </div>
    )
}

export default ErrorPage;