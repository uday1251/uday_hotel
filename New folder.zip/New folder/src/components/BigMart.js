const BigMart = () =>{
    return (
            <div>
                <h1>BigMart Grocery</h1>
            </div>
    )
}

export default BigMart;