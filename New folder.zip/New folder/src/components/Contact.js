const Contact = ()=>{
    return (
        <div>
        <h2>Hello contact</h2>
   </div>   
    )
}
export default Contact;