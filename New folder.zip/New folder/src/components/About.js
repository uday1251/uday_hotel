import React from "react";
import Testmonial from "./Testmonial";

// export default About;

class About extends React.Component{
      constructor(props){
       super(props);
       console.log(props);
       this.state ={
        users :[]
       }  
      }

      async componentDidMount(){
        let data = await fetch("https://api.github.com/users")
        let usersData  = await data.json();
        console.log(usersData); 
         console.log("parent loaded");
         this.setState({
          users:usersData
        })
      }

      componentDidUpdate(){
        debugger;
        console.log("updated.");

      }

      componentWillUnmount(){
        debugger;
          console.log("unmount");
      }
       render(){
          console.log("parent render");
          return <div>
             <h1>About Page</h1>
             <ul>
              {
        
                this.state.users.map((user, index)=>{
                    return <li key={user.index} >{user.login}</li>
                })  
              }
              </ul>
            <Testmonial />
          </div>
        }

}

export default About;