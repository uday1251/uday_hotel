import { useState } from "react";
import MenuItem from "./MenuItem";

const Menu = (Props)=>{
    const [showListIndex,setShowListIndex]= useState(0);
    const {categoryItems} = Props;
    const count = categoryItems?.card?.card?.itemCards ? categoryItems?.card?.card?.itemCards?.length : categoryItems?.card?.card?.categories?.length;
    const setShowList = (index) =>{
        setShowListIndex(index);
    }
    return (
        <div className="mb-4">
        <div className="flex w-full m-auto justify-between bg-yellow-600 p-4">
             <h2 className="font-bold text-md text-white">{categoryItems.card.card.title}({count})</h2>
             
             {categoryItems?.card?.card?.itemCards ?  <span aria-hidden="true" className="before:content-['\E923'] text-white"></span> :''}
            

               
        </div>
        <div className="w-full m-auto bg-gray-100 mb-4 py-4">
               {/* {
                    categoryItems?.card?.card?.itemCards && 
                    categoryItems?.card?.card?.itemCards.map(()=>{
                          return <MenuItem />  
                    })
                } */}
                {
                     categoryItems?.card?.card?.categories && 
                     categoryItems?.card?.card?.categories.map((item, index)=>{
                           return <MenuItem item={item} setShowList = {()=>{ setShowList(index)}} key={index} index={index} ShowList={showListIndex == index? true:false}/>  
                     })
                }
        </div>
        </div>
    )
    
}


export default Menu;