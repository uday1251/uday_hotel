import React from 'react';
import 'swiper/swiper-bundle.css'; // Import Swiper styles
import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Autoplay } from 'swiper';
SwiperCore.use([Autoplay]);
import { BANNER_IMG_URL } from '../utils/constants';


const Slider = (props) => {
 
  return (
    <div className="swiper-container py-2.5">
        <h2 className="text-2xl font-semibold">Best offers for you</h2>
         
    <Swiper
      spaceBetween={10}
      slidesPerView={2.8}
      navigation
      autoplay={{ delay: 2000 }} // Auto-slide every 3 seconds (adjust as needed)
    >
      {
        props.slider.map((slide,index)=>{
          
          return <SwiperSlide className={index} key={index}>
            <a href=""><img className="max-w-full w-80 h-56" src={BANNER_IMG_URL+slide.imageId} /></a>
           </SwiperSlide>
        })
        
      }
      

      
     
      
      
      {/* Add more slides as needed */}
    </Swiper>
    </div>
   
  );
};

export default Slider;
