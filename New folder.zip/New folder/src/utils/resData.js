const restaurants = [
    {
    "info": {
    "id": "495772",
    "name": "Cafe Niloufer",
    "cloudinaryImageId": "e0c63e989612732c70da6d1bb6984850",
    "locality": "Old Mla Quarters Road",
    "areaName": "Himayath Nagar",
    "costForTwo": "₹400 for two",
    "cuisines": [
    "Bakery",
    "Beverages",
    "Snacks",
    "Desserts"
    ],
    "avgRating": 4.6,
    "feeDetails": {
    "restaurantId": "495772",
    "fees": [
    {
    "name": "BASE_DISTANCE",
    "fee": 3000
    },
    {
    "name": "BASE_TIME"
    },
    {
    "name": "ANCILLARY_SURGE_FEE"
    }
    ],
    "totalFee": 3000
    },
    "parentId": "9152",
    "avgRatingString": "4.6",
    "totalRatingsString": "10K+",
    "sla": {
    "deliveryTime": 22,
    "lastMileTravel": 1.9,
    "serviceability": "SERVICEABLE",
    "slaString": "22 mins",
    "lastMileTravelString": "1.9 km",
    "iconType": "ICON_TYPE_EMPTY"
    },
    "availability": {
    "nextCloseTime": "2023-10-12 00:00:00",
    "opened": true
    },
    "badges": {
    "textExtendedBadges": [
    {
    "iconId": "guiltfree/GF_Logo_android_3x",
    "shortDescription": "options available",
    "fontColor": "#7E808C"
    }
    ]
    },
    "isOpen": true,
    "type": "F",
    "badgesV2": {
    "entityBadges": {
    "imageBased": {},
    "textBased": {},
    "textExtendedBadges": {
    "badgeObject": [
    {
    "attributes": {
    "description": "",
    "fontColor": "#7E808C",
    "iconId": "guiltfree/GF_Logo_android_3x",
    "shortDescription": "options available"
    }
    }
    ]
    }
    }
    },
    "aggregatedDiscountInfoV3": {
    "header": "10% OFF",
    "subHeader": "ABOVE ₹650",
    "discountTag": "FLAT DEAL"
    },
    "orderabilityCommunication": {
    "title": {},
    "subTitle": {},
    "message": {},
    "customIcon": {}
    },
    "differentiatedUi": {
    "displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
    "differentiatedUiMediaDetails": {
    "mediaType": "ADS_MEDIA_ENUM_IMAGE",
    "lottie": {},
    "video": {}
    }
    },
    "reviewsSummary": {},
    "displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
    "restaurantOfferPresentationInfo": {}
    },
    "analytics": {
    "context": "seo-data-6f32392e-7e5f-416e-a7b6-2f6c2f9592e3"
    },
    "cta": {
    "link": "https://www.swiggy.com/restaurants/cafe-niloufer-old-mla-quarters-road-himayath-nagar-hyderabad-495772",
    "text": "RESTAURANT_MENU",
    "type": "WEBLINK"
    },
    "widgetId": "collectionV5RestaurantListWidget_SimRestoRelevance_food_seo"
    },
    {
    "info": {
    "id": "237054",
    "name": "Cafe Bahar since 1973",
    "cloudinaryImageId": "yrycuz88yy7lm2qbsdv6",
    "areaName": "Basheer Bagh",
    "costForTwo": "₹300 for two",
    "cuisines": [
    "Biryani",
    "Chinese",
    "Indian",
    "Kebabs",
    "Tandoor"
    ],
    "avgRating": 4.1,
    "feeDetails": {
    "restaurantId": "237054",
    "fees": [
    {
    "name": "BASE_DISTANCE",
    "fee": 2600
    },
    {
    "name": "BASE_TIME"
    },
    {
    "name": "ANCILLARY_SURGE_FEE"
    }
    ],
    "totalFee": 2600
    },
    "parentId": "316607",
    "avgRatingString": "4.1",
    "totalRatingsString": "10K+",
    "sla": {
    "deliveryTime": 20,
    "lastMileTravel": 2.3,
    "serviceability": "SERVICEABLE",
    "slaString": "20 mins",
    "lastMileTravelString": "2.3 km",
    "iconType": "ICON_TYPE_EMPTY"
    },
    "availability": {
    "nextCloseTime": "2023-10-11 23:59:00",
    "opened": true
    },
    "badges": {},
    "isOpen": true,
    "aggregatedDiscountInfoV2": {},
    "type": "F",
    "badgesV2": {
    "entityBadges": {
    "imageBased": {},
    "textBased": {},
    "textExtendedBadges": {}
    }
    },
    "orderabilityCommunication": {
    "title": {},
    "subTitle": {},
    "message": {},
    "customIcon": {}
    },
    "differentiatedUi": {
    "displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
    "differentiatedUiMediaDetails": {
    "mediaType": "ADS_MEDIA_ENUM_IMAGE",
    "lottie": {},
    "video": {}
    }
    },
    "reviewsSummary": {},
    "displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
    "restaurantOfferPresentationInfo": {}
    },
    "analytics": {
    "context": "seo-data-6f32392e-7e5f-416e-a7b6-2f6c2f9592e3"
    },
    "cta": {
    "link": "https://www.swiggy.com/restaurants/cafe-bahar-since-1973-basheer-bagh-hyderabad-237054",
    "text": "RESTAURANT_MENU",
    "type": "WEBLINK"
    },
    "widgetId": "collectionV5RestaurantListWidget_SimRestoRelevance_food_seo"
    },
    {
    "info": {
    "id": "523794",
    "name": "Capital Multi Cuisine Restaurant",
    "cloudinaryImageId": "rkbt9oto4ub6d4uhmu35",
    "locality": "Himayath Nagar",
    "areaName": "Himayath Nagar",
    "costForTwo": "₹350 for two",
    "cuisines": [
    "Biryani",
    "Arabian",
    "Lebanese"
    ],
    "avgRating": 3.8,
    "feeDetails": {
    "restaurantId": "523794",
    "fees": [
    {
    "name": "BASE_DISTANCE",
    "fee": 2600
    },
    {
    "name": "BASE_TIME"
    },
    {
    "name": "ANCILLARY_SURGE_FEE"
    }
    ],
    "totalFee": 2600
    },
    "parentId": "19262",
    "avgRatingString": "3.8",
    "totalRatingsString": "1K+",
    "sla": {
    "deliveryTime": 19,
    "lastMileTravel": 2.1,
    "serviceability": "SERVICEABLE",
    "slaString": "19 mins",
    "lastMileTravelString": "2.1 km",
    "iconType": "ICON_TYPE_EMPTY"
    },
    "availability": {
    "nextCloseTime": "2023-10-12 02:30:00",
    "opened": true
    },
    "badges": {},
    "isOpen": true,
    "type": "F",
    "badgesV2": {
    "entityBadges": {
    "imageBased": {},
    "textBased": {},
    "textExtendedBadges": {}
    }
    },
    "aggregatedDiscountInfoV3": {
    "header": "₹150 OFF",
    "subHeader": "ABOVE ₹299",
    "discountTag": "FLAT DEAL"
    },
    "orderabilityCommunication": {
    "title": {},
    "subTitle": {},
    "message": {},
    "customIcon": {}
    },
    "differentiatedUi": {
    "displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
    "differentiatedUiMediaDetails": {
    "mediaType": "ADS_MEDIA_ENUM_IMAGE",
    "lottie": {},
    "video": {}
    }
    },
    "reviewsSummary": {},
    "displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
    "restaurantOfferPresentationInfo": {}
    },
    "analytics": {
    "context": "seo-data-6f32392e-7e5f-416e-a7b6-2f6c2f9592e3"
    },
    "cta": {
    "link": "https://www.swiggy.com/restaurants/capital-multi-cuisine-restaurant-himayath-nagar-hyderabad-523794",
    "text": "RESTAURANT_MENU",
    "type": "WEBLINK"
    },
    "widgetId": "collectionV5RestaurantListWidget_SimRestoRelevance_food_seo"
    },
    {
    "info": {
    "id": "109168",
    "name": "Al Rabea Al Arabi Cafeteria",
    "cloudinaryImageId": "lu7b9y7xps4icwn6xzfj",
    "locality": "Opposite Lucky Hotel",
    "areaName": "Santosh Nagar",
    "costForTwo": "₹250 for two",
    "cuisines": [
    "Lebanese",
    "Arabian"
    ],
    "avgRating": 4.4,
    "feeDetails": {
    "restaurantId": "109168",
    "fees": [
    {
    "name": "BASE_DISTANCE",
    "fee": 5700
    },
    {
    "name": "BASE_TIME"
    },
    {
    "name": "ANCILLARY_SURGE_FEE"
    }
    ],
    "totalFee": 5700
    },
    "parentId": "7582",
    "avgRatingString": "4.4",
    "totalRatingsString": "10K+",
    "sla": {
    "deliveryTime": 28,
    "lastMileTravel": 6.3,
    "serviceability": "SERVICEABLE",
    "slaString": "28 mins",
    "lastMileTravelString": "6.3 km",
    "iconType": "ICON_TYPE_EMPTY"
    },
    "availability": {
    "nextCloseTime": "2023-10-12 01:00:00",
    "opened": true
    },
    "badges": {},
    "isOpen": true,
    "aggregatedDiscountInfoV2": {},
    "type": "F",
    "badgesV2": {
    "entityBadges": {
    "imageBased": {},
    "textBased": {},
    "textExtendedBadges": {}
    }
    },
    "orderabilityCommunication": {
    "title": {},
    "subTitle": {},
    "message": {},
    "customIcon": {}
    },
    "differentiatedUi": {
    "displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
    "differentiatedUiMediaDetails": {
    "mediaType": "ADS_MEDIA_ENUM_IMAGE",
    "lottie": {},
    "video": {}
    }
    },
    "reviewsSummary": {},
    "displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
    "restaurantOfferPresentationInfo": {}
    },
    "analytics": {
    "context": "seo-data-6f32392e-7e5f-416e-a7b6-2f6c2f9592e3"
    },
    "cta": {
    "link": "https://www.swiggy.com/restaurants/al-rabea-al-arabi-cafeteria-opposite-lucky-hotel-santosh-nagar-hyderabad-109168",
    "text": "RESTAURANT_MENU",
    "type": "WEBLINK"
    },
    "widgetId": "collectionV5RestaurantListWidget_SimRestoRelevance_food_seo"
    },
    {
    "info": {
    "id": "140117",
    "name": "Imperial Multi-Cuisine Restaurant",
    "cloudinaryImageId": "ib97mlmkhuwwv51syyca",
    "locality": "Saroor Nagar West",
    "areaName": "Saroor Nagar West",
    "costForTwo": "₹400 for two",
    "cuisines": [
    "Biryani",
    "Chinese",
    "Indian",
    "Kebabs",
    "Tandoor"
    ],
    "avgRating": 4.2,
    "feeDetails": {
    "restaurantId": "140117",
    "fees": [
    {
    "name": "BASE_DISTANCE",
    "fee": 3800
    },
    {
    "name": "BASE_TIME"
    },
    {
    "name": "ANCILLARY_SURGE_FEE"
    }
    ],
    "totalFee": 3800
    },
    "parentId": "19254",
    "avgRatingString": "4.2",
    "totalRatingsString": "10K+",
    "sla": {
    "deliveryTime": 23,
    "lastMileTravel": 4.1,
    "serviceability": "SERVICEABLE",
    "slaString": "23 mins",
    "lastMileTravelString": "4.1 km",
    "iconType": "ICON_TYPE_EMPTY"
    },
    "availability": {
    "nextCloseTime": "2023-10-11 23:59:00",
    "opened": true
    },
    "badges": {},
    "isOpen": true,
    "type": "F",
    "badgesV2": {
    "entityBadges": {
    "imageBased": {},
    "textBased": {},
    "textExtendedBadges": {}
    }
    },
    "aggregatedDiscountInfoV3": {
    "header": "30% OFF",
    "subHeader": "UPTO ₹75"
    },
    "orderabilityCommunication": {
    "title": {},
    "subTitle": {},
    "message": {},
    "customIcon": {}
    },
    "differentiatedUi": {
    "displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
    "differentiatedUiMediaDetails": {
    "mediaType": "ADS_MEDIA_ENUM_IMAGE",
    "lottie": {},
    "video": {}
    }
    },
    "reviewsSummary": {},
    "displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
    "restaurantOfferPresentationInfo": {}
    },
    "analytics": {
    "context": "seo-data-6f32392e-7e5f-416e-a7b6-2f6c2f9592e3"
    },
    "cta": {
    "link": "https://www.swiggy.com/restaurants/imperial-multi-cuisine-restaurant-saroor-nagar-west-hyderabad-140117",
    "text": "RESTAURANT_MENU",
    "type": "WEBLINK"
    },
    "widgetId": "collectionV5RestaurantListWidget_SimRestoRelevance_food_seo"
    },
    {
    "info": {
    "id": "3363",
    "name": "Sri Narsing Bhelpuri & Juice Centre (Bogulkunta)",
    "cloudinaryImageId": "cfff1vycqx3r86t5elhe",
    "locality": "Tilak Road",
    "areaName": "Koti",
    "costForTwo": "₹200 for two",
    "cuisines": [
    "Indian",
    "North Indian",
    "Chaat",
    "Italian",
    "Beverages",
    "Desserts",
    "Punjabi",
    "Snacks",
    "Pizzas",
    "Burgers"
    ],
    "avgRating": 4.2,
    "veg": true,
    "feeDetails": {
    "restaurantId": "3363",
    "fees": [
    {
    "name": "BASE_DISTANCE",
    "fee": 2600
    },
    {
    "name": "BASE_TIME"
    },
    {
    "name": "ANCILLARY_SURGE_FEE"
    }
    ],
    "totalFee": 2600
    },
    "parentId": "18940",
    "avgRatingString": "4.2",
    "totalRatingsString": "10K+",
    "sla": {
    "deliveryTime": 27,
    "lastMileTravel": 1.2,
    "serviceability": "SERVICEABLE",
    "slaString": "27 mins",
    "lastMileTravelString": "1.2 km",
    "iconType": "ICON_TYPE_EMPTY"
    },
    "availability": {
    "nextCloseTime": "2023-10-11 23:30:00",
    "opened": true
    },
    "badges": {
    "imageBadges": [
    {
    "imageId": "v1695133679/badges/Pure_Veg111.png",
    "description": "pureveg"
    }
    ]
    },
    "isOpen": true,
    "aggregatedDiscountInfoV2": {},
    "type": "F",
    "badgesV2": {
    "entityBadges": {
    "imageBased": {
    "badgeObject": [
    {
    "attributes": {
    "description": "pureveg",
    "imageId": "v1695133679/badges/Pure_Veg111.png"
    }
    }
    ]
    },
    "textBased": {},
    "textExtendedBadges": {}
    }
    },
    "orderabilityCommunication": {
    "title": {},
    "subTitle": {},
    "message": {},
    "customIcon": {}
    },
    "differentiatedUi": {
    "displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
    "differentiatedUiMediaDetails": {
    "mediaType": "ADS_MEDIA_ENUM_IMAGE",
    "lottie": {},
    "video": {}
    }
    },
    "reviewsSummary": {},
    "displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
    "restaurantOfferPresentationInfo": {}
    },
    "analytics": {
    "context": "seo-data-6f32392e-7e5f-416e-a7b6-2f6c2f9592e3"
    },
    "cta": {
    "link": "https://www.swiggy.com/restaurants/sri-narsing-bhelpuri-and-juice-centre-bogulkunta-tilak-road-koti-hyderabad-3363",
    "text": "RESTAURANT_MENU",
    "type": "WEBLINK"
    },
    "widgetId": "collectionV5RestaurantListWidget_SimRestoRelevance_food_seo"
    },
    {
    "info": {
    "id": "7203",
    "name": "Taj Mahal-Abids",
    "cloudinaryImageId": "xtxi8kws7lmnwfardw0b",
    "locality": "Abids Road",
    "areaName": "Koti",
    "costForTwo": "₹300 for two",
    "cuisines": [
    "North Indian",
    "Chinese",
    "South Indian"
    ],
    "avgRating": 4.4,
    "veg": true,
    "feeDetails": {
    "restaurantId": "7203",
    "fees": [
    {
    "name": "BASE_DISTANCE",
    "fee": 2600
    },
    {
    "name": "BASE_TIME"
    },
    {
    "name": "ANCILLARY_SURGE_FEE"
    }
    ],
    "totalFee": 2600
    },
    "parentId": "924",
    "avgRatingString": "4.4",
    "totalRatingsString": "10K+",
    "sla": {
    "deliveryTime": 24,
    "lastMileTravel": 1.7,
    "serviceability": "SERVICEABLE",
    "slaString": "24 mins",
    "lastMileTravelString": "1.7 km",
    "iconType": "ICON_TYPE_EMPTY"
    },
    "availability": {
    "nextCloseTime": "2023-10-11 23:00:00",
    "opened": true
    },
    "badges": {
    "imageBadges": [
    {
    "imageId": "v1695133679/badges/Pure_Veg111.png",
    "description": "pureveg"
    }
    ]
    },
    "isOpen": true,
    "type": "F",
    "badgesV2": {
    "entityBadges": {
    "imageBased": {
    "badgeObject": [
    {
    "attributes": {
    "description": "pureveg",
    "imageId": "v1695133679/badges/Pure_Veg111.png"
    }
    }
    ]
    },
    "textBased": {},
    "textExtendedBadges": {}
    }
    },
    "aggregatedDiscountInfoV3": {
    "header": "30% OFF",
    "subHeader": "UPTO ₹75"
    },
    "orderabilityCommunication": {
    "title": {},
    "subTitle": {},
    "message": {},
    "customIcon": {}
    },
    "differentiatedUi": {
    "displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
    "differentiatedUiMediaDetails": {
    "mediaType": "ADS_MEDIA_ENUM_IMAGE",
    "lottie": {},
    "video": {}
    }
    },
    "reviewsSummary": {},
    "displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
    "restaurantOfferPresentationInfo": {}
    },
    "analytics": {
    "context": "seo-data-6f32392e-7e5f-416e-a7b6-2f6c2f9592e3"
    },
    "cta": {
    "link": "https://www.swiggy.com/restaurants/taj-mahal-abids-abids-road-koti-hyderabad-7203",
    "text": "RESTAURANT_MENU",
    "type": "WEBLINK"
    },
    "widgetId": "collectionV5RestaurantListWidget_SimRestoRelevance_food_seo"
    },
    {
    "info": {
    "id": "721102",
    "name": "Pista House Tea",
    "cloudinaryImageId": "0c3e2dd31d5cab7480ab83d9bd600196",
    "locality": "King Kothi",
    "areaName": "Abids & Koti",
    "costForTwo": "₹500 for two",
    "cuisines": [
    "Beverages",
    "Indian"
    ],
    "avgRating": 4.3,
    "feeDetails": {
    "restaurantId": "721102",
    "fees": [
    {
    "name": "BASE_DISTANCE",
    "fee": 2600
    },
    {
    "name": "BASE_TIME"
    },
    {
    "name": "ANCILLARY_SURGE_FEE"
    }
    ],
    "totalFee": 2600
    },
    "parentId": "236815",
    "avgRatingString": "4.3",
    "totalRatingsString": "50+",
    "sla": {
    "deliveryTime": 17,
    "lastMileTravel": 1.2,
    "serviceability": "SERVICEABLE",
    "slaString": "17 mins",
    "lastMileTravelString": "1.2 km",
    "iconType": "ICON_TYPE_EMPTY"
    },
    "availability": {
    "nextCloseTime": "2023-10-11 19:00:00",
    "opened": true
    },
    "badges": {},
    "isOpen": true,
    "aggregatedDiscountInfoV2": {},
    "type": "F",
    "badgesV2": {
    "entityBadges": {
    "imageBased": {},
    "textBased": {},
    "textExtendedBadges": {}
    }
    },
    "orderabilityCommunication": {
    "title": {},
    "subTitle": {},
    "message": {},
    "customIcon": {}
    },
    "differentiatedUi": {
    "displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
    "differentiatedUiMediaDetails": {
    "mediaType": "ADS_MEDIA_ENUM_IMAGE",
    "lottie": {},
    "video": {}
    }
    },
    "reviewsSummary": {},
    "displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
    "isNewlyOnboarded": true,
    "restaurantOfferPresentationInfo": {}
    },
    "analytics": {
    "context": "seo-data-6f32392e-7e5f-416e-a7b6-2f6c2f9592e3"
    },
    "cta": {
    "link": "https://www.swiggy.com/restaurants/pista-house-tea-king-kothi-abids-and-koti-hyderabad-721102",
    "text": "RESTAURANT_MENU",
    "type": "WEBLINK"
    },
    "widgetId": "collectionV5RestaurantListWidget_SimRestoRelevance_food_seo"
    },
    {
    "info": {
    "id": "6927",
    "name": "Bombay Juice",
    "cloudinaryImageId": "fngjhkvws1o6ehegeyrv",
    "locality": "Sultan Bazar",
    "areaName": "Koti",
    "costForTwo": "₹200 for two",
    "cuisines": [
    "Chaat",
    "Chinese",
    "Juices"
    ],
    "avgRating": 4.3,
    "veg": true,
    "feeDetails": {
    "restaurantId": "6927",
    "fees": [
    {
    "name": "BASE_DISTANCE",
    "fee": 2600
    },
    {
    "name": "BASE_TIME"
    },
    {
    "name": "ANCILLARY_SURGE_FEE"
    }
    ],
    "totalFee": 2600
    },
    "parentId": "3843",
    "avgRatingString": "4.3",
    "totalRatingsString": "10K+",
    "sla": {
    "deliveryTime": 20,
    "lastMileTravel": 1,
    "serviceability": "SERVICEABLE",
    "slaString": "20 mins",
    "lastMileTravelString": "1.0 km",
    "iconType": "ICON_TYPE_EMPTY"
    },
    "availability": {
    "nextCloseTime": "2023-10-12 00:00:00",
    "opened": true
    },
    "badges": {
    "imageBadges": [
    {
    "imageId": "v1695133679/badges/Pure_Veg111.png",
    "description": "pureveg"
    }
    ],
    "textExtendedBadges": [
    {
    "iconId": "guiltfree/GF_Logo_android_3x",
    "shortDescription": "options available",
    "fontColor": "#7E808C"
    }
    ]
    },
    "isOpen": true,
    "aggregatedDiscountInfoV2": {},
    "type": "F",
    "badgesV2": {
    "entityBadges": {
    "imageBased": {
    "badgeObject": [
    {
    "attributes": {
    "description": "pureveg",
    "imageId": "v1695133679/badges/Pure_Veg111.png"
    }
    }
    ]
    },
    "textBased": {},
    "textExtendedBadges": {
    "badgeObject": [
    {
    "attributes": {
    "description": "",
    "fontColor": "#7E808C",
    "iconId": "guiltfree/GF_Logo_android_3x",
    "shortDescription": "options available"
    }
    }
    ]
    }
    }
    },
    "orderabilityCommunication": {
    "title": {},
    "subTitle": {},
    "message": {},
    "customIcon": {}
    },
    "differentiatedUi": {
    "displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
    "differentiatedUiMediaDetails": {
    "mediaType": "ADS_MEDIA_ENUM_IMAGE",
    "lottie": {},
    "video": {}
    }
    },
    "reviewsSummary": {},
    "displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
    "restaurantOfferPresentationInfo": {}
    },
    "analytics": {
    "context": "seo-data-6f32392e-7e5f-416e-a7b6-2f6c2f9592e3"
    },
    "cta": {
    "link": "https://www.swiggy.com/restaurants/bombay-juice-sultan-bazar-koti-hyderabad-6927",
    "text": "RESTAURANT_MENU",
    "type": "WEBLINK"
    },
    "widgetId": "collectionV5RestaurantListWidget_SimRestoRelevance_food_seo"
    }
    ];

export default restaurants;