const Bestres = () => {
  
    return(
        <div className="py-2.5">
             <h2 className="text-2xl font-semibold">Best offers for you</h2>
             <div className="py-2.5 flex justify-between">
                    <a href=""><img className="max-w-full w-80 h-56" src="https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_850,h_504/rng/md/carousel/production/8cc24abf8ab66c5ef6c1bd56a4d3728c" /></a>
                    <a href=""><img className="max-w-full w-80 h-56" src="https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_850,h_504/rng/md/carousel/production/3e0bb76dfb8650b0c4c456588b4fa0fd" /></a>
                    <a href=""><img className="max-w-full w-80 h-56" src="https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_850,h_504/rng/md/carousel/production/3e0bb76dfb8650b0c4c456588b4fa0fd" /></a>
             </div>
             
             
        </div>
    );
       
};

export default Bestres;
