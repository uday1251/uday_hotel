import Header from "./Header";
import { Outlet } from "react-router-dom";
import About from "./About";

const HomePage = () => {
    return(
     
        <div>
            <Header/>
            <Outlet />
           
        </div>
    );
     
}

export default HomePage;