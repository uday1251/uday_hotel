import React, { lazy, Suspense } from "react";
import ReactDOM from "react-dom/client";
import HomePage from "./components/Homepage";
import Body  from "./components/Body";
import {createBrowserRouter, RouterProvider  } from "react-router-dom";
import About from "./components/About";
import Contact from "./components/Contact";
import ErrorPage from "./components/ErrorPage";
import Details from "./components/Details";
//import BigMart from "./components/BigMart";

const BigMart = lazy(()=>import('./components/BigMart'));
const appRoutes = createBrowserRouter(
  [
    {
     path:"/",
     element: <HomePage/>,
     errorElement:<ErrorPage />,
     children:[
      {
        path:"/",
        element:<Body />
      },
      {
      path:"/about",
      element:<About/>
     },
     {
      path:"/contact",
      element:<Contact/>
     },
     {
      path:"/restaurants/:resID",
      element:<Details />
     },
     {
      path:"bigmart",
      element:<Suspense fallback={<h1>Loading...</h1>}><BigMart /></Suspense>
     }
    
    ]
   }]

);

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
    <div>
      <RouterProvider router={appRoutes}  />
     </div>
)